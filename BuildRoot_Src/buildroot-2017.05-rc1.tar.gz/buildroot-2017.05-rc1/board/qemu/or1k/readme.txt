Run the emulation with:

 qemu-system-or32 -kernel output/images/vmlinux -nographic

The login prompt will appear in the terminal that started Qemu.

Ethernet support is not working, yet.

Tested with QEMU 2.8.0.
